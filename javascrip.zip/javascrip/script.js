for(var a=0; a<5; a++){
    for(var b=0; a<=b; b++){
        document.write("★");
    }
    document.write("<br>");
}