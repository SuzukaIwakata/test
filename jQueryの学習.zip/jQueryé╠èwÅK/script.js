$(function(){
    $("p").mouseover(function(){
        $("p").css("color","red");
    });
});